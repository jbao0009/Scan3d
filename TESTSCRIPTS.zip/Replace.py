#THIS SCRIPT REPLACES XYZ VALUES

import re, pprint

startline=-1  #start point +2 (-1 means all points replaced )
newvalx=[]
newvaly=[]
newvalz=[]

def containsNumber(value):
    for character in value:
        if character.isdigit():
            return True
    return False

#替换xyz值的脚本
    
#输入3个文件：
#-机器人离线编程软件ROBOGUIDE输出的LS文件
#-算法转换后的关键点 
#-输出的ls文件

with open("ROBOT.LS", "r") as k,open("transformedpoints.txt", "r") as j, open("OUT.LS", "w") as o:
    #read data into list
    for linestore in j:
        strin = linestore.strip('\n')
        valu=strin.split(',')
        #print(valu)
        newvalx.append(round(float(valu[0]),2))
        newvaly.append(round(float(valu[1]),2))
        newvalz.append(round(float(valu[2]),2))
        
    index=1
    pntnmb=0
    #write data into txt
    for line in k:
        #print(line)
        newline=line
        xval=0
        yval=0
        zval=0
        cnt=0
        coord=line.find("X =")
        spd=line.find(" P[")
        
        #print(s)
        #change coordinates--这里改xyz
        if( coord!=-1):
            chunks = line.split(' ')
            #print((chunks))
            
            for i in range(0,len(chunks)):
                if (cnt==0) and containsNumber(chunks[i]): 
                    xval=chunks[i]
                    cnt=1
                    
                elif (cnt==1) and containsNumber(chunks[i]):
                    yval=chunks[i]
                    cnt=2
                    
                elif (cnt==2) and containsNumber(chunks[i]):
                    zval=chunks[i]
                    cnt=3

            try:
                nx=float(xval)
                ny=float(yval)
                nz=float(zval)
                #print(pntnmb)
                if pntnmb>startline:
                    nx=newvalx[pntnmb-startline-1]
                    ny=newvaly[pntnmb-startline-1]     
                    nz=newvalz[pntnmb-startline-1]
                    newline="	X =   "+format(ny)+"  mm,	Y =    "+format(nx)+"  mm,	Z =   "+format(nz)+"  mm,"
                    print(newline)
                    
                pntnmb=pntnmb+1
            except:
                
                print('error')
                nx=nx 
                
        #change speed and blend radius  
        #这里改速度
        elif( spd!=-1): 
            spd2=line.find("mm/sec")
            if( spd2!=-1): 
                chunks2 = line.split(' ')
                #print(chunks2)
                    #这里以后改速度 
                    #=======================================
        else:
            newline=line
        o.write("{}\n".format(newline.rstrip()))
        index += 1
    print("fin")
