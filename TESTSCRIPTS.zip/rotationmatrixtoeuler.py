import numpy as np
import open3d as o3d
import copy

def rotation_angles(matrix, order):
    """
    input
        matrix = 3x3 rotation matrix (numpy array)
        oreder(str) = rotation order of x, y, z : e.g, rotation XZY -- 'xzy'
    output
        theta1, theta2, theta3 = rotation angles in rotation order
    """
    r11, r12, r13 = matrix[0]
    r21, r22, r23 = matrix[1]
    r31, r32, r33 = matrix[2]

    if order == 'xzx':
        theta1 = np.arctan(r31 / r21)
        theta2 = np.arctan(r21 / (r11 * np.cos(theta1)))
        theta3 = np.arctan(-r13 / r12)

    elif order == 'xyx':
        theta1 = np.arctan(-r21 / r31)
        theta2 = np.arctan(-r31 / (r11 *np.cos(theta1)))
        theta3 = np.arctan(r12 / r13)

    elif order == 'yxy':
        theta1 = np.arctan(r12 / r32)
        theta2 = np.arctan(r32 / (r22 *np.cos(theta1)))
        theta3 = np.arctan(-r21 / r23)

    elif order == 'yzy':
        theta1 = np.arctan(-r32 / r12)
        theta2 = np.arctan(-r12 / (r22 *np.cos(theta1)))
        theta3 = np.arctan(r23 / r21)

    elif order == 'zyz':
        theta1 = np.arctan(r23 / r13)
        theta2 = np.arctan(r13 / (r33 *np.cos(theta1)))
        theta3 = np.arctan(-r32 / r31)

    elif order == 'zxz':
        theta1 = np.arctan(-r13 / r23)
        theta2 = np.arctan(-r23 / (r33 *np.cos(theta1)))
        theta3 = np.arctan(r31 / r32)

    elif order == 'xzy':
        theta1 = np.arctan(r32 / r22)
        theta2 = np.arctan(-r12 * np.cos(theta1) / r22)
        theta3 = np.arctan(r13 / r11)

    elif order == 'xyz':
        theta1 = np.arctan(-r23 / r33)
        theta2 = np.arctan(r13 * np.cos(theta1) / r33)
        theta3 = np.arctan(-r12 / r11)

    elif order == 'yxz':
        theta1 = np.arctan(r13 / r33)
        theta2 = np.arctan(-r23 * np.cos(theta1) / r33)
        theta3 = np.arctan(r21 / r22)

    elif order == 'yzx':
        theta1 = np.arctan(-r31 / r11)
        theta2 = np.arctan(r21 * np.cos(theta1) / r11)
        theta3 = np.arctan(-r23 / r22)

    elif order == 'zyx':
        theta1 = np.arctan(r21 / r11)
        theta2 = np.arctan(-r31 * np.cos(theta1) / r11)
        theta3 = np.arctan(r32 / r33)

    elif order == 'zxy':
        theta1 = np.arctan(-r12 / r22)
        theta2 = np.arctan(r32 * np.cos(theta1) / r22)
        theta3 = np.arctan(-r31 / r33)

    theta1 = theta1 * 180 / np.pi
    theta2 = theta2 * 180 / np.pi
    theta3 = theta3 * 180 / np.pi

    return (theta1, theta2, theta3)

zeropnt=[-45.8205, 0.0684726, 0.310394]
 
dpath="/home/yimu/Downloads/ball.ply"
mesh = o3d.io.read_point_cloud(dpath)
mesh = mesh.translate(zeropnt, relative=False)

rot1=np.array([[0.867991  ,0.103459,  0.485683 ,  6.57573],
[0.298606 ,-0.890216 ,-0.344024  , 63.1908],
[0.39677 , 0.443638 ,-0.803592  , 185.029],
[       0      ,  0         ,0     ,    1]])
    
rot2=  np.array([[ 0.909612  , 0.334952  ,-0.245799 ,   33.8413],
  [0.270357 ,-0.0279845  , 0.962355 ,    112.22],
  [0.315464  ,-0.941821 , -0.116011 ,   192.701],
   [      0  ,        0     ,     0  ,        1]])   
    
    
rot3=  np.array([[ 0.759147 , 0.254755 ,-0.598996   , 47.985],
[ 0.629622 ,-0.053926 , 0.775028 ,  48.7275],
[  0.16514 ,-0.965501, -0.201337  , 190.641],
[        0,         0,         0,         1  ]])
    
    
    
rot4=   np.array([[  0.796952, 0.0980287 , 0.596037,  22.7258],
[-0.544397 ,-0.310987 , 0.779051 ,  95.6182],
[ 0.261729 ,-0.945347 ,-0.194475 ,  158.504],
[        0,         0,         0,         1]])
    
    
rot5=   np.array([[   0.732326 , -0.564842 ,  0.380335 ,   22.6079],
[ -0.510584, -0.0859119 ,  0.855525 ,   101.958],
[ -0.450562 , -0.820715  ,-0.351314  ,  138.934],
[         0,          0,          0,          1]])
    
    
    
rot6=  np.array([[   0.856211 ,-0.489936 , -0.16391,  16.6166],
[0.0486122 ,-0.239459  ,0.969689,   116.868],
[-0.514335, -0.838226 ,-0.181211  , 143.511],
[        0 ,        0,         0,         1]])
        
        

rot1s=rot1[0:3,0:3]
print (rot1s)
test1=rotation_angles(rot1s,'zyx')
print (test1)








#    
#mesh_t = copy.deepcopy(mesh).transform(rot1)
#
#mesh_t2 = copy.deepcopy(mesh).transform(rot2)
#
#mesh_t3 = copy.deepcopy(mesh).transform(rot3)
#mesh_t4 = copy.deepcopy(mesh).transform(rot4)
#mesh_t5 = copy.deepcopy(mesh).transform(rot5)
#mesh_t6 = copy.deepcopy(mesh).transform(rot6)
#
#dpatho="/home/yimu/Downloads/pcd_0813/point1/point1.pcd"
#pcdo = o3d.io.read_point_cloud(dpatho)
#
#dpatho2="/home/yimu/Downloads/pcd_0813/point2/point2.pcd"
#pcdo2 = o3d.io.read_point_cloud(dpatho2)
#
#dpatho3="/home/yimu/Downloads/pcd_0813/point3/point3.pcd"
#pcdo3 = o3d.io.read_point_cloud(dpatho3)
#dpatho4="/home/yimu/Downloads/pcd_0813/point4/point4.pcd"
#pcdo4 = o3d.io.read_point_cloud(dpatho4)
#dpatho5="/home/yimu/Downloads/pcd_0813/point5/point5.pcd"
#pcdo5 = o3d.io.read_point_cloud(dpatho5)
#dpatho6="/home/yimu/Downloads/pcd_0813/point6/point6.pcd"
#pcdo6 = o3d.io.read_point_cloud(dpatho6)

#o3d.visualization.draw_geometries([mesh_t, mesh_t2,mesh_t3, mesh_t4,mesh_t5, mesh_t6,pcdo, pcdo2, pcdo3, pcdo4, pcdo5, pcdo6])