import open3d as o3d
import copy

#x=-524.472
#y=-31.011
#z=333.528

transformmatrix=[[0.998713254929, 0.047482155263, 0.017812522128, -60.491085052490],
[-0.047519605607, 0.998868882656, 0.001684985822, -36.563720703125],
[-0.017712367699, -0.002529261634, 0.999839901924, -152.994338989258],
[0.000000000000, 0.000000000000, 0.000000000000, 1.000000000000]]

dpath="/home/yimu/Downloads/pcd_0813/plate/plate.pcd"
pcd = o3d.io.read_point_cloud(dpath)
 

mesh_s = copy.deepcopy(pcd).transform((transformmatrix))


o3d.visualization.draw_geometries([pcd, mesh_s])