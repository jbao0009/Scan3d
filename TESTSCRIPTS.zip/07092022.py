#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Sep 27 11:01:33 2022

@author: yimu
"""
import open3d as o3d
import numpy as np

matrix=np.matrix([[ 6.46407749e-02, -9.59561191e-01,  2.73977903e-01, -513.097746],
 [-2.39333624e-01, -2.81446301e-01, -9.29250987e-01,  57.0145280],
 [ 9.68783251e-01, -5.50462062e-03, -2.47848164e-01,  5.26896585],
 [ 0.00000000e+00,  0.00000000e+00,  0.00000000e+00,  1.00000000e+00]])


matrix=np.linalg.inv(matrix)

print (matrix)

voxel_size = 0.3


 
dpath="/home/yimu/Downloads/hball.ply"

mesh1p="/home/yimu/Downloads/PCD_scans/6dian_0826/mesh1.ply"
 

source = o3d.io.read_point_cloud(mesh1p)
target = o3d.io.read_point_cloud(dpath)

source=source.voxel_down_sample(voxel_size)
target=target.voxel_down_sample(voxel_size)

mesh1 = (target).transform((matrix))

o3d.visualization.draw_geometries([  mesh1,source])
