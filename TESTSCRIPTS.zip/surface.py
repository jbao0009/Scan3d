import open3d as o3d
import numpy as np
import copy
import cv2 
import pandas as pd
from PIL import Image as pil

def draw_registration_result(source, target, transformation):
    source_temp = copy.deepcopy(source)
    target_temp = copy.deepcopy(target)
    source_temp.paint_uniform_color([1, 0.706, 0])
    target_temp.paint_uniform_color([0, 0.651, 0.929])
    source_temp.transform(transformation)
    o3d.visualization.draw_geometries([source_temp, target_temp],
                                      zoom=0.4459,
                                      front=[0.9288, -0.2951, -0.2242],
                                      lookat=[1.6784, 2.0612, 1.4451],
                                      up=[-0.3402, -0.9189, -0.1996])

 
def get_flattened_pcds2(source,A,B,C,D,x0,y0,z0): 
    x1 = np.asarray(source.points)[:,0] 
    y1 = np.asarray(source.points)[:,1] 
    z1 = np.asarray(source.points)[:,2] 
    x0 = x0 * np.ones(x1.size) 
    y0 = y0 * np.ones(y1.size) 
    z0 = z0 * np.ones(z1.size) 
    r = np.power(np.square(x1-x0)+np.square(y1-y0)+np.square(z1-z0),0.5) 
    a = (x1-x0)/r 
    b = (y1-y0)/r 
    c = (z1-z0)/r 
    t = -1 * (A * np.asarray(source.points)[:,0] + B * np.asarray(source.points)[:,1] + C * np.asarray(source.points)[:,2] + D) 
    t = t / (a*A+b*B+c*C) 
    np.asarray(source.points)[:,0] = x1 + a * t 
    np.asarray(source.points)[:,1] = y1 + b * t 
    np.asarray(source.points)[:,2] = z1 + c * t 
    return source


def get_flat_matrix(a,b,c,d):
    costh=c/(np.sqrt(a*a+b*b+c*c))
    sinth=np.sqrt((a*a+b*b)/(a*a+b*b+c*c))
    u1=b/(np.sqrt(a*a+b*b+c*c))
    u2=-(a/(np.sqrt(a*a+b*b+c*c)))
    mat=[[(costh+u1*u1*(1-costh)), u1*u2*(1-costh), u2*sinth ],
         [u1*u2*(1-costh), (costh+u1*u1*(1-costh)), -(u1*sinth)],
         [-(u2*sinth), u1*sinth, costh]]
    
    
    return mat

dpath="/home/yimu/Downloads/plytest/Meshd.ply"
 
  

 
pcd = o3d.io.read_point_cloud(dpath)


pcd=pcd.voxel_down_sample(voxel_size=0.05)
 
matrix=[ [-0.073231182992, -0.997297644615, -0.005878227297, 541.029235839844,],
[0.997307956219, -0.073207251728, -0.004187665414, 160.167358398438,],
[0.003746019909, -0.006169070955, 0.999973952770, -132.093673706055,],
[0.000000000000, 0.000000000000, 0.000000000000, 1.000000000000]]

pcd = (pcd).transform((matrix))



## For Vanilla ICP (double)

# Search distance for Nearest Neighbour Search [Hybrid-Search is used].
max_correspondence_distance = 0.07


plane_model, inliers = pcd.segment_plane(distance_threshold=0.1,ransac_n=3,
                                         num_iterations=1000)
 



[a, b, c, d] = plane_model

print(f"Plane equation: {a:.2f}x + {b:.2f}y + {c:.2f}z + {d:.2f} = 0")
 
inlier_cloud = pcd.select_by_index(inliers)
inlier_cloud.paint_uniform_color([1.0, 0, 0])





plane=get_flattened_pcds2(inlier_cloud,a,b,c,d,0,0,0)

#plane = copy.deepcopy(plane).translate((40, 0, 0))


outlier_cloud = pcd.select_by_index(inliers, invert=True)

 
 

write_text = True
#o3d.io.write_point_cloud("cadmeshplane.ply", plane, write_ascii=write_text)
#o3d.visualization.draw_geometries([plane],window_name='t01')




#plane = copy.deepcopy(plane).translate((400, 0, 0))

np_val=np.array(plane.points)

npconv=[]
np_val = np.delete(np_val, 2, 1)
 
data = pil.fromarray(np_val)

scale=10

x=np_val[:, 0]
y=np_val[:, 1]

img = np.zeros((700*scale,600*scale),dtype=np.uint8)
img =  cv2.cvtColor(img, cv2.COLOR_GRAY2RGB)

for i in range(np_val.shape[0]):
    a=round(np_val[i,0]*scale+10*scale)
    #print(a)
    b=round(np_val[i,1]*scale)
    b=np.int0(b)
    a=np.int0(a)
    img[a,b]=255
    
    
    
#blur image for canny edge detect 
blurred = cv2.GaussianBlur(img, (5, 5), 0)
    
df = pd.read_csv('data.csv')

r1 = list(df.loc[0])#x values
r2 = list(df.loc[1])#y values   
del r1[0]
del r2[0]


for i,x in enumerate(r1):
    y=r2[i]
    print (x,y)
    x=np.int0(x*scale)
    y=np.int0(y*scale)
    
    cv2.circle(img=img, center = (x,y), radius =50, color =(255,0,255), thickness=20)

    
cv2.namedWindow('detected', cv2.WINDOW_NORMAL)


wins=(48000, 24000)
thresh = cv2.resize(img, wins)

cv2.imwrite("show1.bmp", img)
cv2.imshow('detected',img)
 

cv2.waitKey(0)
cv2.destroyAllWindows()
    
    
    
    
    
    