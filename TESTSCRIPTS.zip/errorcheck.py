#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Aug 18 08:48:50 2022

@author: yimu
"""
import numpy as np

scanball1=[-33.92742858,  49.15500788, 166.31069196]
scanball2=[ -8.50882091,  99.59350504, 177.8291846 ]
scanball3=[ 12.49270006,  19.25201376, 182.76650818]
scanball4=[-14.52502056, 121.09854305, 146.02720699]
scanball5=[-11.52270203, 125.78398478, 159.67217499]
scanball6=[-23.4393937,  114.54334267, 167.28423051]

calc1=[-33.0382,49.3408,166.63]
calc2=[-7.89093,100.129,178.146]
calc3=[13.032,20.1148,182.946]
calc4= [-13.5992,120.783,146.387]
calc5= [-10.8682,125.613,159.414]
calc6= [-22.6998,114.925,166.965]  

print(np.subtract(scanball1,calc1))
print(np.subtract(scanball2,calc2))
print(np.subtract(scanball3,calc3))
print(np.subtract(scanball4,calc4))
print(np.subtract(scanball5,calc5))
print(np.subtract(scanball6,calc6))
