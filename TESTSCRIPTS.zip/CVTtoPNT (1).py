import re, pprint
#modification values

#xmod=4     356.4         63.555        237.6
#ymod=5.5
#219 240 270
#330.3,-55.2,279.3
xmod=10
ymod=10
zmod=0
startline=2

#P5 211.8,35.76000000000002,303.0]
#210.8
#35.74
#303
#37.000410.51,-213.36

def containsNumber(value):
    for character in value:
        if character.isdigit():
            return True
    return False


#CHANGE X AND Y to be same as camera
 
for gj in range(1,8):

    with open("GJ"+str(gj)+".LS", "r") as i, open("pnt"+str(gj)+".txt", "w") as o:
        index = 1
        for line in i:
            #print(line)
            #newline=line
            xval=0
            yval=0
            zval=0
            cnt=0
            s=line.find("X =")
            #print(s)
            if( s!=-1):
                chunks = line.split(' ')
                #print((chunks))
                
                
                for i in range(0,len(chunks)):
                    if (cnt==0) and containsNumber(chunks[i]): 
                        xval=chunks[i]
                        #print(xval)
                        
                        #print(cnt)
                        cnt=1
                        
                    elif (cnt==1) and containsNumber(chunks[i]):
                        
                        #print(yval)
                        yval=chunks[i]
                        
                        #print(cnt)
                        cnt=2
                        
                    elif (cnt==2) and containsNumber(chunks[i]):
                        
                        zval=chunks[i]
                        #print(zval)
                        
                        #print(cnt)
                        cnt=3
                 
                
                print(xval)
                print(yval)
                print(zval)
                
     
                
                try:
                    nx=float(xval)
                    ny=float(yval)
                    nz=float(zval)
                     
                    nx=nx+xmod
                    ny=ny+ymod
                    nz=nz+zmod 
                    
                      #CHANGE X AND Y to be same as camera
    
                    newline=""+format(ny)+","+format(nx)+","+format(nz)+" "
                    print(newline)
                    o.write("{}\n".format(newline.rstrip()))
                except:
                    #print(sp)
                    nx=nx 
                    
                #print(numxyz)
    
                
            else: 
                n=1
            
            
            index += 1
        print("fin")
