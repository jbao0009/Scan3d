#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Aug 18 14:57:29 2022

@author: yimu
"""
import open3d as o3d
import numpy as np
import copy
import quarternions

def rotation_matrix(theta1, theta2, theta3, order='xyz'):
    """
    input
        theta1, theta2, theta3 = rotation angles in rotation order (degrees)
        oreder = rotation order of x,y,z　e.g. XZY rotation -- 'xzy'
    output
        3x3 rotation matrix (numpy array)
    """
    c1 = np.cos(theta1 * np.pi / 180)
    s1 = np.sin(theta1 * np.pi / 180)
    c2 = np.cos(theta2 * np.pi / 180)
    s2 = np.sin(theta2 * np.pi / 180)
    c3 = np.cos(theta3 * np.pi / 180)
    s3 = np.sin(theta3 * np.pi / 180)

    if order == 'xzx':
        matrix=np.array([[c2, -c3*s2, s2*s3], 
                         [c1*s2, c1*c2*c3-s1*s3, -c3*s1-c1*c2*s3], 
                         [s1*s2, c1*s3+c2*c3*s1, c1*c3-c2*s1*s3]])
    elif order=='xyx':
        matrix=np.array([[c2, s2*s3, c3*s2], 
                         [s1*s2, c1*c3-c2*s1*s3, -c1*s3-c2*c3*s1], 
                         [-c1*s2, c3*s1+c1*c2*s3, c1*c2*c3-s1*s3]])
    elif order=='yxy':
        matrix=np.array([[c1*c3-c2*s1*s3, s1*s2, c1*s3+c2*c3*s1], 
                         [s2*s3, c2, -c3*s2], 
                         [-c3*s1-c1*c2*s3, c1*s2, c1*c2*c3-s1*s3]])
    elif order=='yzy':
        matrix=np.array([[c1*c2*c3-s1*s3, -c1*s2, c3*s1+c1*c2*s3], 
                         [c3*s2, c2, s2*s3], 
                         [-c1*s3-c2*c3*s1, s1*s2, c1*c3-c2*s1*s3]])
    elif order=='zyz':
        matrix=np.array([[c1*c2*c3-s1*s3, -c3*s1-c1*c2*s3, c1*s2], 
                         [c1*s3+c2*c3*s1, c1*c3-c2*s1*s3, s1*s2], 
                         [-c3*s2, s2*s3, c2]])
    elif order=='zxz':
        matrix=np.array([[c1*c3-c2*s1*s3, -c1*s3-c2*c3*s1, s1*s2], 
                         [c3*s1+c1*c2*s3, c1*c2*c3-s1*s3, -c1*s2], 
                         [s2*s3, c3*s2, c2]])
    elif order=='xyz':
        matrix=np.array([[c2*c3, -c2*s3, s2], 
                         [c1*s3+c3*s1*s2, c1*c3-s1*s2*s3, -c2*s1], 
                         [s1*s3-c1*c3*s2, c3*s1+c1*s2*s3, c1*c2]])
    elif order=='xzy':
        matrix=np.array([[c2*c3, -s2, c2*s3], 
                         [s1*s3+c1*c3*s2, c1*c2, c1*s2*s3-c3*s1], 
                         [c3*s1*s2-c1*s3, c2*s1, c1*c3+s1*s2*s3]])
    elif order=='yxz':
        matrix=np.array([[c1*c3+s1*s2*s3, c3*s1*s2-c1*s3, c2*s1], 
                         [c2*s3, c2*c3, -s2], 
                         [c1*s2*s3-c3*s1, c1*c3*s2+s1*s3, c1*c2]])
    elif order=='yzx':
        matrix=np.array([[c1*c2, s1*s3-c1*c3*s2, c3*s1+c1*s2*s3], 
                         [s2, c2*c3, -c2*s3], 
                         [-c2*s1, c1*s3+c3*s1*s2, c1*c3-s1*s2*s3]])
    elif order=='zyx':
        matrix=np.array([[c1*c2, c1*s2*s3-c3*s1, s1*s3+c1*c3*s2], 
                         [c2*s1, c1*c3+s1*s2*s3, c3*s1*s2-c1*s3], 
                         [-s2, c2*s3, c2*c3]])
    elif order=='zxy':
        matrix=np.array([[c1*c3-s1*s2*s3, -c2*s1, c1*s3+c3*s1*s2], 
                         [c3*s1+c1*s2*s3, c1*c2, s1*s3-c1*c3*s2], 
                         [-c2*s3, s2, c2*c3]])

    return matrix


def rotation_angles(matrix, order):
    """
    input
        matrix = 3x3 rotation matrix (numpy array)
        oreder(str) = rotation order of x, y, z : e.g, rotation XZY -- 'xzy'
    output
        theta1, theta2, theta3 = rotation angles in rotation order
    """
    r11, r12, r13 = matrix[0]
    r21, r22, r23 = matrix[1]
    r31, r32, r33 = matrix[2]
    
    if order == 'xzx':
        theta1 = np.arctan(r31 / r21)
        theta2 = np.arctan(r21 / (r11 * np.cos(theta1)))
        theta3 = np.arctan(-r13 / r12)
    
    elif order == 'xyx':
        theta1 = np.arctan(-r21 / r31)
        theta2 = np.arctan(-r31 / (r11 *np.cos(theta1)))
        theta3 = np.arctan(r12 / r13)
    
    elif order == 'yxy':
        theta1 = np.arctan(r12 / r32)
        theta2 = np.arctan(r32 / (r22 *np.cos(theta1)))
        theta3 = np.arctan(-r21 / r23)
        
    elif order == 'yzy':
        theta1 = np.arctan(-r32 / r12)
        theta2 = np.arctan(-r12 / (r22 *np.cos(theta1)))
        theta3 = np.arctan(r23 / r21)
    
    elif order == 'zyz':
        theta1 = np.arctan(r23 / r13)
        theta2 = np.arctan(r13 / (r33 *np.cos(theta1)))
        theta3 = np.arctan(-r32 / r31)
        
    elif order == 'zxz':
        theta1 = np.arctan(-r13 / r23)
        theta2 = np.arctan(-r23 / (r33 *np.cos(theta1)))
        theta3 = np.arctan(r31 / r32)
        
    elif order == 'xzy':
        theta1 = np.arctan(r32 / r22)
        theta2 = np.arctan(-r12 * np.cos(theta1) / r22)
        theta3 = np.arctan(r13 / r11)
        
    elif order == 'xyz':
        theta1 = np.arctan(-r23 / r33)
        theta2 = np.arctan(r13 * np.cos(theta1) / r33)
        theta3 = np.arctan(-r12 / r11)
        
    elif order == 'yxz':
        theta1 = np.arctan(r13 / r33)
        theta2 = np.arctan(-r23 * np.cos(theta1) / r33)
        theta3 = np.arctan(r21 / r22)
        
    elif order == 'yzx':
        theta1 = np.arctan(-r31 / r11)
        theta2 = np.arctan(r21 * np.cos(theta1) / r11)
        theta3 = np.arctan(-r23 / r22)
    
    elif order == 'zyx':
        theta1 = np.arctan(r21 / r11)
        theta2 = np.arctan(-r31 * np.cos(theta1) / r11)
        theta3 = np.arctan(r32 / r33)
    
    elif order == 'zxy':
        theta1 = np.arctan(-r12 / r22)
        theta2 = np.arctan(r32 * np.cos(theta1) / r22)
        theta3 = np.arctan(-r31 / r33)
    
    theta1 = theta1 * 180 / np.pi
    theta2 = theta2 * 180 / np.pi
    theta3 = theta3 * 180 / np.pi
    
    return (theta1, theta2, theta3)


robp1=  np.array([825.462,62.533,107.305,-19.041,65.329,-26.621])

axisp1= np.array([-802.72,0.501,340.435])

robp2=  np.array([787.778,23.087,96.253,-7.287,66.565,-13.756])

axisp2= np.array([-800.069,0.501,340.435])

robp3=  np.array([829.163,79.503,66.689,20.521,70.971,-11.504])

axisp3= np.array([-750.036,0.501,340.435])

robp4=  np.array([1002.286,26.953,106.311,175.312,72.509,-150.715])

axisp4= np.array([-800.221,0.501,340.435])

robp5=  np.array([1049.797,41.017,-35.899,147.677,7.411,-164.591])

axisp5= np.array([-800.021,0.501,340.435])

robp6=  np.array([897.029,10.585,-46.945,147.134,-4.626,163.497])

axisp6= np.array([-800.183,0.501,340.435])

robr1=robp1[3:6]
robr2=robp2[3:6]
robr3=robp3[3:6]
robr4=robp4[3:6]
robr5=robp5[3:6]
robr6=robp6[3:6]

#quart1=quarternions.get_quaternion_from_euler(robr1)
#quart2=quarternions.get_quaternion_from_euler(robr2)
#quart3=quarternions.get_quaternion_from_euler(robr3)
#quart4=quarternions.get_quaternion_from_euler(robr4)
#quart5=quarternions.get_quaternion_from_euler(robr5)
#quart6=quarternions.get_quaternion_from_euler(robr6)
#
#
#rmtx1=quarternions.quaternion_rotation_matrix(quart1)
#rmtx2=quarternions.quaternion_rotation_matrix(quart2)
#rmtx3=quarternions.quaternion_rotation_matrix(quart3)
#rmtx4=quarternions.quaternion_rotation_matrix(quart4)
#rmtx5=quarternions.quaternion_rotation_matrix(quart5)
#rmtx6=quarternions.quaternion_rotation_matrix(quart6)
#
#
#print (rmtx1)

order='xyz'

rmtx1=rotation_matrix(robr1[0], robr1[1], robr1[2], order)
rmtx2=rotation_matrix(robr2[0], robr2[1], robr2[2], order)
rmtx3=rotation_matrix(robr3[0], robr3[1], robr3[2], order)
rmtx4=rotation_matrix(robr4[0], robr4[1], robr4[2], order)
rmtx5=rotation_matrix(robr5[0], robr5[1], robr5[2], order)
rmtx6=rotation_matrix(robr6[0], robr6[1], robr6[2], order)



robc1=robp1[0:3]
robc2=robp2[0:3]
robc3=robp3[0:3]
robc4=robp4[0:3]
robc5=robp5[0:3]
robc6=robp6[0:3]

#print (robc1)

tmtx1=np.column_stack((rmtx1,robc1))
tmtx2=np.column_stack((rmtx2,robc2))
tmtx3=np.column_stack((rmtx3,robc3))
tmtx4=np.column_stack((rmtx4,robc4))
tmtx5=np.column_stack((rmtx5,robc5))
tmtx6=np.column_stack((rmtx6,robc6))

row_added = np.array([0, 0,0,1])

tmtx1 = np.r_[tmtx1,[row_added]]
tmtx2 = np.r_[tmtx2,[row_added]]
tmtx3 = np.r_[tmtx3,[row_added]]
tmtx4 = np.r_[tmtx4,[row_added]]
tmtx5 = np.r_[tmtx5,[row_added]]
tmtx6 = np.r_[tmtx6,[row_added]]


if 1==1:
    print (tmtx1)
    print (tmtx2)
    print (tmtx3)
    print (tmtx4)
    print (tmtx5)
    print (tmtx6)


#Robot positions>????????? 

#are translation and rotation independent?
dpath="/home/yimu/Downloads/plytest/ball.ply"
mesh = o3d.io.read_point_cloud(dpath)



R1 = mesh.get_rotation_matrix_from_zyx((robr1[0], robr1[1], robr1[2]))
R2 = mesh.get_rotation_matrix_from_zyx((robr2[0], robr2[1], robr2[2]))
R3 = mesh.get_rotation_matrix_from_zyx((robr3[0], robr3[1], robr3[2]))
R4 = mesh.get_rotation_matrix_from_zyx((robr4[0], robr4[1], robr4[2]))
R5 = mesh.get_rotation_matrix_from_zyx((robr5[0], robr5[1], robr5[2]))
R6 = mesh.get_rotation_matrix_from_zyx((robr6[0], robr6[1], robr6[2]))


S1 = mesh.get_rotation_matrix_from_xyz((robr1[0], robr1[1], robr1[2]))
S2 = mesh.get_rotation_matrix_from_xyz((robr2[0], robr2[1], robr2[2]))
S3 = mesh.get_rotation_matrix_from_xyz((robr3[0], robr3[1], robr3[2]))
S4 = mesh.get_rotation_matrix_from_xyz((robr4[0], robr4[1], robr4[2]))
S5 = mesh.get_rotation_matrix_from_xyz((robr5[0], robr5[1], robr5[2]))
S6 = mesh.get_rotation_matrix_from_xyz((robr6[0], robr6[1], robr6[2]))



print (R1)
print (S1)

zeropnt=np.array([-45.8205, 0.0684726, 0.310394])

tmtxR1=np.column_stack((R1,robc1))
tmtxR2=np.column_stack((R2,robc2))
tmtxR3=np.column_stack((R3,robc3))
tmtxR4=np.column_stack((R4,robc4))
tmtxR5=np.column_stack((R5,robc5))
tmtxR6=np.column_stack((R6,robc6))

 

tmtxR1 = np.r_[tmtxR1,[row_added]]
tmtxR2 = np.r_[tmtxR2,[row_added]]
tmtxR3 = np.r_[tmtxR3,[row_added]]
tmtxR4 = np.r_[tmtxR4,[row_added]]
tmtxR5 = np.r_[tmtxR5,[row_added]]
tmtxR6 = np.r_[tmtxR6,[row_added]]


tmtxS1=np.column_stack((S1,robc1))
tmtxS2=np.column_stack((S2,robc2))
tmtxS3=np.column_stack((S3,robc3))
tmtxS4=np.column_stack((S4,robc4))
tmtxS5=np.column_stack((S5,robc5))
tmtxS6=np.column_stack((S6,robc6))

 

tmtxS1 = np.r_[tmtxS1,[row_added]]
tmtxS2 = np.r_[tmtxS2,[row_added]]
tmtxS3 = np.r_[tmtxS3,[row_added]]
tmtxS4 = np.r_[tmtxS4,[row_added]]
tmtxS5 = np.r_[tmtxS5,[row_added]]
tmtxS6 = np.r_[tmtxS6,[row_added]]



mesh.paint_uniform_color([0, 1 ,0.1])


mesh1 = copy.deepcopy(mesh).transform(tmtxR1)
mesh2 = copy.deepcopy(mesh).transform(tmtxR2)
mesh3 = copy.deepcopy(mesh).transform(tmtxR3)
mesh4 = copy.deepcopy(mesh).transform(tmtxR4)
mesh5 = copy.deepcopy(mesh).transform(tmtxR5)
mesh6 = copy.deepcopy(mesh).transform(tmtxR6)
 
mesh.paint_uniform_color([1, 1 ,0.1])

mesh1b = copy.deepcopy(mesh).transform(tmtxS1)
mesh2b = copy.deepcopy(mesh).transform(tmtxS2)
mesh3b = copy.deepcopy(mesh).transform(tmtxS3)
mesh4b = copy.deepcopy(mesh).transform(tmtxS4)
mesh5b = copy.deepcopy(mesh).transform(tmtxS5)
mesh6b = copy.deepcopy(mesh).transform(tmtxS6)
 




#blue
mesh.paint_uniform_color([0.1, 0.1, 1])


if 1==1:

        
#    mesh1a = copy.deepcopy(mesh).rotate(rmtx1)
#    mesh2a = copy.deepcopy(mesh).rotate(rmtx2)
#    mesh3a = copy.deepcopy(mesh).rotate(rmtx3)
#    mesh4a = copy.deepcopy(mesh).rotate(rmtx4)
#    mesh5a = copy.deepcopy(mesh).rotate(rmtx5)
#    mesh6a = copy.deepcopy(mesh).rotate(rmtx6)   
#    
#    
##    robc1[0]= robc1[0]+0.01
##    robc2[0]= robc1[0]+0.01
##    robc3[0]= robc1[0]+0.01
##    robc4[0]= robc1[0]+0.01
##    robc5[0]= robc1[0]+0.01
##    robc6[0]= robc1[0]+0.01
#    
#    mesh1a = copy.deepcopy(mesh1a).translate(robc1)
#    mesh2a = copy.deepcopy(mesh2a).translate(robc2)
#    mesh3a = copy.deepcopy(mesh3a).translate(robc3)
#    mesh4a = copy.deepcopy(mesh4a).translate(robc4)
#    mesh5a = copy.deepcopy(mesh5a).translate(robc5)
#    mesh6a = copy.deepcopy(mesh6a).translate(robc6)
    
    mesh1a = copy.deepcopy(mesh).transform(tmtx1)
    mesh2a = copy.deepcopy(mesh).transform(tmtx2)
    mesh3a = copy.deepcopy(mesh).transform(tmtx3)
    mesh4a = copy.deepcopy(mesh).transform(tmtx4)
    mesh5a = copy.deepcopy(mesh).transform(tmtx5)
    mesh6a = copy.deepcopy(mesh).transform(tmtx6)



#+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#copy start heree
#+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

#plot scanned tool positions
#+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++


def swapPositions(list, pos1, pos2):
     
    list[pos1], list[pos2] = list[pos2], list[pos1]
    return list

debug=0

robp1=  np.array([825.462,62.533,107.305,-19.041,65.329,-26.621])

axisp1= np.array([-802.72,0.501,340.435])

robp2=  np.array([787.778,23.087,96.253,-7.287,66.565,-13.756])

axisp2= np.array([-800.069,0.501,340.435])

robp3=  np.array([829.163,79.503,66.689,20.521,70.971,-11.504])

axisp3= np.array([-750.036,0.501,340.435])

robp4=  np.array([1002.286,26.953,106.311,175.312,72.509,-150.715])

axisp4= np.array([-800.221,0.501,340.435])

robp5=  np.array([1049.797,41.017,-35.899,147.677,7.411,-164.591])

axisp5= np.array([-800.021,0.501,340.435])

robp6=  np.array([897.029,10.585,-46.945,147.134,-4.626,163.497])

axisp6= np.array([-800.183,0.501,340.435])



zeropnt=np.array([-45.8205, 0.0684726, 0.310394])
 
dpath="/home/yimu/Downloads/ball.ply"
mesh = o3d.io.read_point_cloud(dpath)
#mesh = mesh.translate(zeropnt, relative=False)

rot1=np.array([[0.867991  ,0.103459,  0.485683 ,  6.57573],
[0.298606 ,-0.890216 ,-0.344024  , 63.1908],
[0.39677 , 0.443638 ,-0.803592  , 185.029],
[       0      ,  0         ,0     ,    1]])
    
rot2=  np.array([[ 0.909612  , 0.334952  ,-0.245799 ,   33.8413],
  [0.270357 ,-0.0279845  , 0.962355 ,    112.22],
  [0.315464  ,-0.941821 , -0.116011 ,   192.701],
   [      0  ,        0     ,     0  ,        1]])   
    
    
rot3=  np.array([[ 0.759147 , 0.254755 ,-0.598996   , 47.985],
[ 0.629622 ,-0.053926 , 0.775028 ,  48.7275],
[  0.16514 ,-0.965501, -0.201337  , 190.641],
[        0,         0,         0,         1  ]])
    
    
    
rot4=   np.array([[  0.796952, 0.0980287 , 0.596037,  22.7258],
[-0.544397 ,-0.310987 , 0.779051 ,  95.6182],
[ 0.261729 ,-0.945347 ,-0.194475 ,  158.504],
[        0,         0,         0,         1]])
    
    
rot5=   np.array([[   0.732326 , -0.564842 ,  0.380335 ,   22.6079],
[ -0.510584, -0.0859119 ,  0.855525 ,   101.958],
[ -0.450562 , -0.820715  ,-0.351314  ,  138.934],
[         0,          0,          0,          1]])
    
    
    
rot6=  np.array([[   0.856211 ,-0.489936 , -0.16391,  16.6166],
[0.0486122 ,-0.239459  ,0.969689,   116.868],
[-0.514335, -0.838226 ,-0.181211  , 143.511],
[        0 ,        0,         0,         1]])
        
        


calculated=1

if calculated==1:

    scanball1=np.array([-33.0382,49.3408,166.63])
    scanball2=np.array([-7.89093,100.129,178.146])
    scanball3=np.array([13.032,20.1148,182.946])
    scanball4=np.array([-13.5992,120.783,146.387])
    scanball5=np.array([-10.8682,125.613,159.414])
    scanball6=np.array([-22.6998,114.925,166.965])

else:
#measured from meshlab
    scanball1=np.array([-33.92742858,  49.15500788, 166.31069196])
    scanball2=np.array([ -8.50882091,  99.59350504, 177.8291846 ])
    scanball3=np.array([ 12.49270006,  19.25201376, 182.76650818])
    scanball4=np.array([-14.52502056, 121.09854305, 146.02720699])
    scanball5=np.array([-11.52270203, 125.78398478, 159.67217499])
    scanball6=np.array([-23.4393937,  114.54334267, 167.28423051])

positive=0 #which direction????


axisdiff1=np.subtract(axisp1,axisp1)
axisdiff2=np.subtract(axisp2,axisp1)
axisdiff3=np.subtract(axisp3,axisp1)
axisdiff4=np.subtract(axisp4,axisp1)
axisdiff5=np.subtract(axisp5,axisp1)
axisdiff6=np.subtract(axisp6,axisp1)

axisdiff1=swapPositions(axisdiff1, 0, 1)
axisdiff2=swapPositions(axisdiff2, 0, 1)
axisdiff3=swapPositions(axisdiff3, 0, 1)
axisdiff4=swapPositions(axisdiff4, 0, 1)
axisdiff5=swapPositions(axisdiff5, 0, 1)
axisdiff6=swapPositions(axisdiff6, 0, 1)

if 1==1:
    print('difference ')
    print(axisdiff1)
    print(axisdiff2)
    print(axisdiff3)
    print(axisdiff4)
    print(axisdiff5)
    print(axisdiff6)


scanballdiff1=np.subtract(scanball1,axisdiff1)
scanballdiff2=np.subtract(scanball2,axisdiff2)
scanballdiff3=np.subtract(scanball3,axisdiff3)
scanballdiff4=np.subtract(scanball4,axisdiff4)
scanballdiff5=np.subtract(scanball5,axisdiff5)
scanballdiff6=np.subtract(scanball6,axisdiff6)

if 1==0:
    print('difference (abs pos rel to first point)')
    print(scanballdiff1)
    print(scanballdiff2)
    print(scanballdiff3)
    print(scanballdiff4)
    print(scanballdiff5)
    print(scanballdiff6)

robxyz1=robp1[:3]
robxyz2=robp2[:3]
robxyz3=robp3[:3]
robxyz4=robp4[:3]
robxyz5=robp5[:3]
robxyz6=robp6[:3]


sub1=np.subtract(scanballdiff1,robxyz1)
sub2=np.subtract(scanballdiff2,robxyz2)
sub3=np.subtract(scanballdiff3,robxyz3)
sub4=np.subtract(scanballdiff4,robxyz4)
sub5=np.subtract(scanballdiff5,robxyz5)
sub6=np.subtract(scanballdiff6,robxyz6)

if 1==0:
    print(sub1)
    print(sub2)
    print(sub3)
    print(sub4)
    print(sub5)
    print(sub6)

mesh.paint_uniform_color([0.9, 0.1, 0.1])

mesh_t = copy.deepcopy(mesh).transform(rot1)

mesh_t2 = copy.deepcopy(mesh).transform(rot2)

mesh_t3 = copy.deepcopy(mesh).transform(rot3)
mesh_t4 = copy.deepcopy(mesh).transform(rot4)
mesh_t5 = copy.deepcopy(mesh).transform(rot5)
mesh_t6 = copy.deepcopy(mesh).transform(rot6)

#scanned tool positions 
mesh_t = mesh_t.translate(axisdiff1)
mesh_t2 = mesh_t2.translate(axisdiff2)
mesh_t3 = mesh_t3.translate(axisdiff3)
mesh_t4 = mesh_t4.translate(axisdiff4)
mesh_t5 = mesh_t5.translate(axisdiff5)
mesh_t6 = mesh_t6.translate(axisdiff6)


 



o3d.visualization.draw_geometries([mesh,mesh1,mesh2,mesh3,mesh4,mesh5,mesh6,
                                   mesh_t, mesh_t2,mesh_t3, mesh_t4,mesh_t5, mesh_t6,
                                   mesh1a,mesh2a,mesh3a,mesh4a,mesh5a,mesh6a,
                                   mesh1b,mesh2b,mesh3b,mesh4b,mesh5b,mesh6b,
                                   ])


#o3d.visualization.draw_geometries([mesh_t, mesh_t2,mesh_t3, mesh_t4,mesh_t5, mesh_t6