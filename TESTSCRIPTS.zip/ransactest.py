import open3d as o3d
import numpy as np
import copy

def draw_registration_result(source, target, transformation):
    source_temp = copy.deepcopy(source)
    target_temp = copy.deepcopy(target)
    source_temp.paint_uniform_color([1, 0.706, 0])
    target_temp.paint_uniform_color([0, 0.651, 0.929])
    source_temp.transform(transformation)
    o3d.visualization.draw_geometries([source_temp, target_temp],
                                      zoom=0.4459,
                                      front=[0.9288, -0.2951, -0.2242],
                                      lookat=[1.6784, 2.0612, 1.4451],
                                      up=[-0.3402, -0.9189, -0.1996])


dpath="/home/yimu/Downloads/pcd_0813/plate/plate.pcd"
dpath2="/home/yimu/Downloads/plytest/scan.ply"
        
threshold = 0.02   

trans_init = np.asarray([[0.98, 00, -0.07, 0.05],
                         [-0.0139, 0.98, -0.15, 0.7],
                         [0.087, 0.255, 0.98, -0.4], [0.0, 0.0, 0.0, 1.0]])
                         
                         
pcd = o3d.io.read_point_cloud(dpath)
target = o3d.io.read_point_cloud(dpath)




## For Vanilla ICP (double)

# Search distance for Nearest Neighbour Search [Hybrid-Search is used].
max_correspondence_distance = 0.07


plane_model, inliers = pcd.segment_plane(distance_threshold=1,
                                             ransac_n=3,
                                             num_iterations=1000)

 


[a, b, c, d] = plane_model

print(f"Plane equation: {a:.2f}x + {b:.2f}y + {c:.2f}z + {d:.2f} = 0")
print("Displaying pointcloud with planar points in red ...")
inlier_cloud = pcd.select_by_index(inliers)
inlier_cloud.paint_uniform_color([1.0, 0, 0])

 

outlier_cloud = pcd.select_by_index(inliers, invert=True)


inlier_cloud.estimate_normals(
        search_param=o3d.geometry.KDTreeSearchParamHybrid(radius=0.1, max_nn=30))

pcl = inlier_cloud.sample_points_poisson_disk(number_of_points=10000)
hull, _ = pcl.compute_convex_hull()
hull_ls = o3d.geometry.LineSet.create_from_triangle_mesh(hull)
hull_ls.paint_uniform_color((1, 0, 0))
o3d.visualization.draw([pcl, hull_ls])
 
o3d.visualization.draw_geometries([inlier_cloud],window_name='t01')
 