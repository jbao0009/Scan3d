from PIL import Image as pil
import matplotlib.pyplot as plt
import numpy as np
import cv2
import csv 
import pandas as pd


df = pd.read_csv('data.csv')
 
 

r1 = list(df.loc[0])
r2 = list(df.loc[1])
del r1[0]
del r2[0]
print (r1)
print (r2)