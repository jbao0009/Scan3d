import open3d as o3d
import copy
import numpy as np
#x=-524.472
#y=-31.011
#z=333.528

filename='/home/yimu/Downloads/PCD_scans/parts0829/part3plate.png'

depth=o3d.io.read_image(filename)

pcd = o3d.geometry.PointCloud.create_from_depth_image(depth, 
            o3d.camera.PinholeCameraIntrinsic(
            o3d.camera.PinholeCameraIntrinsicParameters.PrimeSenseDefault)
            ,
            np.identity(4),
            depth_scale=1000.0, depth_trunc=1000.0)
# flip the orientation, so it looks upright, not upside-down
pcd.transform([[1,0,0,0],[0,-1,0,0],[0,0,-1,0],[0,0,0,1]])

o3d.visualization.draw_geometries([pcd])