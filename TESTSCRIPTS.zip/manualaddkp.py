#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Aug 23 13:02:16 2022

@author: yimu
"""

from PIL import Image as pil
import matplotlib.pyplot as plt
import numpy as np
import cv2


from typing import Tuple

def resize_with_pad(image: np.array, 
                    new_shape: Tuple[int, int], 
                    padding_color: Tuple[int] = (255, 255, 255)) -> np.array:
    """Maintains aspect ratio and resizes with padding.
    Params:
        image: Image to be resized.
        new_shape: Expected (width, height) of new image.
        padding_color: Tuple in BGR of padding color
    Returns:
        image: Resized image with padding
    """
    original_shape = (image.shape[1], image.shape[0])
    ratio = float(max(new_shape))/max(original_shape)
    new_size = tuple([int(x*ratio) for x in original_shape])
    image = cv2.resize(image, new_size)
    delta_w = new_shape[0] - new_size[0]
    delta_h = new_shape[1] - new_size[1]
    top, bottom = delta_h//2, delta_h-(delta_h//2)
    left, right = delta_w//2, delta_w-(delta_w//2)
    image = cv2.copyMakeBorder(image, top, bottom, left, right, cv2.BORDER_CONSTANT, value=padding_color)
    return image
  
    
contour="/home/yimu/Downloads/plytest/savedImage.png"
kpmanual="/home/yimu/Downloads/08-2022/20220819LS/manualkp.png"



img1 = cv2.imread(contour)
img2 = cv2.imread(kpmanual)



print(img1.shape)
print(img2.shape)

img1 = resize_with_pad(img1, (img2.shape[1], img2.shape[0]),(0,0,0))

img = cv2.add(img1,img2)

filename = 'addedkp.png'
  
# Using cv2.imwrite() method
# Saving the image
cv2.imwrite(filename, img)


cv2.imshow("show", img)
cv2.waitKey(0)
cv2.destroyAllWindows()
