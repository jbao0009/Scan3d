import open3d as o3d
import numpy as np
import copy
import cv2 
from PIL import Image as pil

def draw_registration_result(source, target, transformation):
    source_temp = copy.deepcopy(source)
    target_temp = copy.deepcopy(target)
    source_temp.paint_uniform_color([1, 0.706, 0])
    target_temp.paint_uniform_color([0, 0.651, 0.929])
    source_temp.transform(transformation)
    o3d.visualization.draw_geometries([source_temp, target_temp],
                                      zoom=0.4459,
                                      front=[0.9288, -0.2951, -0.2242],
                                      lookat=[1.6784, 2.0612, 1.4451],
                                      up=[-0.3402, -0.9189, -0.1996])

 
def get_flattened_pcds2(source,A,B,C,D,x0,y0,z0): 
    x1 = np.asarray(source.points)[:,0] 
    y1 = np.asarray(source.points)[:,1] 
    z1 = np.asarray(source.points)[:,2] 
    x0 = x0 * np.ones(x1.size) 
    y0 = y0 * np.ones(y1.size) 
    z0 = z0 * np.ones(z1.size) 
    r = np.power(np.square(x1-x0)+np.square(y1-y0)+np.square(z1-z0),0.5) 
    a = (x1-x0)/r 
    b = (y1-y0)/r 
    c = (z1-z0)/r 
    t = -1 * (A * np.asarray(source.points)[:,0] + B * np.asarray(source.points)[:,1] + C * np.asarray(source.points)[:,2] + D) 
    t = t / (a*A+b*B+c*C) 
    np.asarray(source.points)[:,0] = x1 + a * t 
    np.asarray(source.points)[:,1] = y1 + b * t 
    np.asarray(source.points)[:,2] = z1 + c * t 
    return source


def get_flat_matrix(a,b,c,d):
    costh=c/(np.sqrt(a*a+b*b+c*c))
    sinth=np.sqrt((a*a+b*b)/(a*a+b*b+c*c))
    u1=b/(np.sqrt(a*a+b*b+c*c))
    u2=-(a/(np.sqrt(a*a+b*b+c*c)))
    mat=[[(costh+u1*u1*(1-costh)), u1*u2*(1-costh), u2*sinth ],
         [u1*u2*(1-costh), (costh+u1*u1*(1-costh)), -(u1*sinth)],
         [-(u2*sinth), u1*sinth, costh]]
    
    
    return mat

dpath="/home/yimu/Downloads/plytest/cadmeshpt.ply"
 
  

 
pcd = o3d.io.read_point_cloud(dpath)
 



## For Vanilla ICP (double)

# Search distance for Nearest Neighbour Search [Hybrid-Search is used].
max_correspondence_distance = 0.07


plane_model, inliers = pcd.segment_plane(distance_threshold=0.1,ransac_n=3,
                                         num_iterations=1000)
 




[a, b, c, d] = plane_model

print(f"Plane equation: {a:.2f}x + {b:.2f}y + {c:.2f}z + {d:.2f} = 0")
 
inlier_cloud = pcd.select_by_index(inliers)
inlier_cloud.paint_uniform_color([1.0, 0, 0])

plane=get_flattened_pcds2(inlier_cloud,a,b,c,d,0,0,0)

outlier_cloud = pcd.select_by_index(inliers, invert=True)

mat=get_flat_matrix(a,b,c,d)
plane = copy.deepcopy(plane).rotate(mat)

write_text = True
o3d.io.write_point_cloud("cadmeshplane.ply", plane, write_ascii=write_text)
#o3d.visualization.draw_geometries([plane],window_name='t01')






np_val=np.array(plane.points)
 
data = pil.fromarray(np_val)

scale=10

x=np_val[:, 0]
y=np_val[:, 1]

img = np.zeros((200*scale,200*scale),dtype=np.uint8)

for i in range(np_val.shape[0]):
    a=round(np_val[i,0]*scale+10*scale)
    #print(a)
    b=round(np_val[i,1]*scale)
    img[a,b]=255
    
    
    
#blur image for canny edge detect 
blurred = cv2.GaussianBlur(img, (5, 5), 0)
    
    
    
cv2.imwrite("show1.bmp", img)
cv2.imshow('detected circles',blurred)
 

cv2.waitKey(0)
cv2.destroyAllWindows()
    
    
    
    
    
    