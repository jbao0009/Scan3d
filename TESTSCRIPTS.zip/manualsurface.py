import open3d as o3d
import numpy as np
import copy
import cv2 

 
dpath="/home/yimu/Downloads/plytest/cadmeshplane.ply"
 
 
pcd = o3d.io.read_point_cloud(dpath)
 

 
 

plane_model, inliers = pcd.segment_plane(distance_threshold=0.1,ransac_n=3,
                                         num_iterations=1000)
 


[a, b, c, d] = plane_model

print(f"Plane equation: {a:.2f}x + {b:.2f}y + {c:.2f}z + {d:.2f} = 0")
 
inlier_cloud = pcd.select_by_index(inliers)
inlier_cloud.paint_uniform_color([1.0, 0, 0])

 

outlier_cloud = pcd.select_by_index(inliers, invert=True)




write_text = True

#o3d.visualization.draw_geometries([inlier_cloud],window_name='t01')

#Plane equation: 0.00x + -0.01y + 1.00z + -145.00 = 0



pcd_r = copy.deepcopy(pcd)
pcd_r.paint_uniform_color([0, 1, 0.1])
R = pcd.get_rotation_matrix_from_xyz((-.0066, -0.0022, 0))

#rotate by camera skew angle?????? calculated manually for now 

pcd_r.rotate(R)
o3d.visualization.draw_geometries([pcd, pcd_r])
print(pcd_r)
o3d.io.write_point_cloud("rotatedcadmesh.ply", pcd_r, write_ascii=write_text)

np_val=np.array(pcd_r)

print(np_val)

 