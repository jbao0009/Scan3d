#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Aug 19 16:28:46 2022

@author: yimu
"""
import numpy as np
import copy
import open3d as o3d

robp1=  np.array([825.462,62.533,107.305,-19.041,65.329,-26.621])

axisp1= np.array([-802.72,0.501,340.435])

robp2=  np.array([787.778,23.087,96.253,-7.287,66.565,-13.756])

axisp2= np.array([-800.069,0.501,340.435])

robp3=  np.array([829.163,79.503,66.689,20.521,70.971,-11.504])

axisp3= np.array([-750.036,0.501,340.435])

robp4=  np.array([1002.286,26.953,106.311,175.312,72.509,-150.715])

axisp4= np.array([-800.221,0.501,340.435])

robp5=  np.array([1049.797,41.017,-35.899,147.677,7.411,-164.591])

axisp5= np.array([-800.021,0.501,340.435])

robp6=  np.array([897.029,10.585,-46.945,147.134,-4.626,163.497])

axisp6= np.array([-800.183,0.501,340.435])

robr1=robp1[3:6]
robr2=robp2[3:6]
robr3=robp3[3:6]
robr4=robp4[3:6]
robr5=robp5[3:6]
robr6=robp6[3:6]


order='xyz'
row_added = np.array([0, 0,0,1])


tool8=np.array([74.7,266.6,77.7,-90.4,-32.2,165.2])


tool8c=tool8[0:3]

robc1=robp1[0:3]
robc2=robp2[0:3]
robc3=robp3[0:3]
robc4=robp4[0:3]
robc5=robp5[0:3]
robc6=robp6[0:3]

 
dpath="/home/yimu/Downloads/ball.ply"
mesh = o3d.io.read_point_cloud(dpath)

mesh.paint_uniform_color([1, 1 ,0.1])



mesh1 = copy.deepcopy(mesh).translate(robc1)
mesh2 = copy.deepcopy(mesh).translate(robc2)
mesh3 = copy.deepcopy(mesh).translate(robc3)
mesh4 = copy.deepcopy(mesh).translate(robc4)
mesh5 = copy.deepcopy(mesh).translate(robc5)
mesh6 = copy.deepcopy(mesh).translate(robc6)



mesh1t = copy.deepcopy(mesh1).translate(tool8c)
mesh2t = copy.deepcopy(mesh2).translate(tool8c)
mesh3t = copy.deepcopy(mesh3).translate(tool8c)
mesh4t = copy.deepcopy(mesh4).translate(tool8c)
mesh5t = copy.deepcopy(mesh5).translate(tool8c)
mesh6t = copy.deepcopy(mesh6).translate(tool8c)

mesh1t.paint_uniform_color([0, 1 ,0.1])
mesh2t.paint_uniform_color([0, 1 ,0.1])
mesh3t.paint_uniform_color([0, 1 ,0.1])
mesh4t.paint_uniform_color([0, 1 ,0.1])
mesh5t.paint_uniform_color([0, 1 ,0.1])
mesh6t.paint_uniform_color([0, 1 ,0.1])


################################\\

###########COPYYYY SCANNED POINTS HERER
def swapPositions(list, pos1, pos2):
     
    list[pos1], list[pos2] = list[pos2], list[pos1]
    return list

debug=0

rot1=np.array([[0.867991  ,0.103459,  0.485683 ,  6.57573],
[0.298606 ,-0.890216 ,-0.344024  , 63.1908],
[0.39677 , 0.443638 ,-0.803592  , 185.029],
[       0      ,  0         ,0     ,    1]])
    
rot2=  np.array([[ 0.909612  , 0.334952  ,-0.245799 ,   33.8413],
  [0.270357 ,-0.0279845  , 0.962355 ,    112.22],
  [0.315464  ,-0.941821 , -0.116011 ,   192.701],
   [      0  ,        0     ,     0  ,        1]])   
    
    
rot3=  np.array([[ 0.759147 , 0.254755 ,-0.598996   , 47.985],
[ 0.629622 ,-0.053926 , 0.775028 ,  48.7275],
[  0.16514 ,-0.965501, -0.201337  , 190.641],
[        0,         0,         0,         1  ]])
    
    
    
rot4=   np.array([[  0.796952, 0.0980287 , 0.596037,  22.7258],
[-0.544397 ,-0.310987 , 0.779051 ,  95.6182],
[ 0.261729 ,-0.945347 ,-0.194475 ,  158.504],
[        0,         0,         0,         1]])
    
    
rot5=   np.array([[   0.732326 , -0.564842 ,  0.380335 ,   22.6079],
[ -0.510584, -0.0859119 ,  0.855525 ,   101.958],
[ -0.450562 , -0.820715  ,-0.351314  ,  138.934],
[         0,          0,          0,          1]])
    
    
    
rot6=  np.array([[   0.856211 ,-0.489936 , -0.16391,  16.6166],
[0.0486122 ,-0.239459  ,0.969689,   116.868],
[-0.514335, -0.838226 ,-0.181211  , 143.511],
[        0 ,        0,         0,         1]])
        
        


calculated=1

if calculated==1:

    scanball1=np.array([-33.0382,49.3408,166.63])
    scanball2=np.array([-7.89093,100.129,178.146])
    scanball3=np.array([13.032,20.1148,182.946])
    scanball4=np.array([-13.5992,120.783,146.387])
    scanball5=np.array([-10.8682,125.613,159.414])
    scanball6=np.array([-22.6998,114.925,166.965])

else:
#measured from meshlab
    scanball1=np.array([-33.92742858,  49.15500788, 166.31069196])
    scanball2=np.array([ -8.50882091,  99.59350504, 177.8291846 ])
    scanball3=np.array([ 12.49270006,  19.25201376, 182.76650818])
    scanball4=np.array([-14.52502056, 121.09854305, 146.02720699])
    scanball5=np.array([-11.52270203, 125.78398478, 159.67217499])
    scanball6=np.array([-23.4393937,  114.54334267, 167.28423051])

positive=0 #which direction????


axisdiff1=np.subtract(axisp1,axisp1)
axisdiff2=np.subtract(axisp2,axisp1)
axisdiff3=np.subtract(axisp3,axisp1)
axisdiff4=np.subtract(axisp4,axisp1)
axisdiff5=np.subtract(axisp5,axisp1)
axisdiff6=np.subtract(axisp6,axisp1)

axisdiff1=swapPositions(axisdiff1, 0, 1)
axisdiff2=swapPositions(axisdiff2, 0, 1)
axisdiff3=swapPositions(axisdiff3, 0, 1)
axisdiff4=swapPositions(axisdiff4, 0, 1)
axisdiff5=swapPositions(axisdiff5, 0, 1)
axisdiff6=swapPositions(axisdiff6, 0, 1)

if 1==1:
    print('difference ')
    print(axisdiff1)
    print(axisdiff2)
    print(axisdiff3)
    print(axisdiff4)
    print(axisdiff5)
    print(axisdiff6)


scanballdiff1=np.subtract(scanball1,axisdiff1)
scanballdiff2=np.subtract(scanball2,axisdiff2)
scanballdiff3=np.subtract(scanball3,axisdiff3)
scanballdiff4=np.subtract(scanball4,axisdiff4)
scanballdiff5=np.subtract(scanball5,axisdiff5)
scanballdiff6=np.subtract(scanball6,axisdiff6)

if 1==0:
    print('difference (abs pos rel to first point)')
    print(scanballdiff1)
    print(scanballdiff2)
    print(scanballdiff3)
    print(scanballdiff4)
    print(scanballdiff5)
    print(scanballdiff6)

robxyz1=robp1[:3]
robxyz2=robp2[:3]
robxyz3=robp3[:3]
robxyz4=robp4[:3]
robxyz5=robp5[:3]
robxyz6=robp6[:3]


sub1=np.subtract(scanballdiff1,robxyz1)
sub2=np.subtract(scanballdiff2,robxyz2)
sub3=np.subtract(scanballdiff3,robxyz3)
sub4=np.subtract(scanballdiff4,robxyz4)
sub5=np.subtract(scanballdiff5,robxyz5)
sub6=np.subtract(scanballdiff6,robxyz6)

if 1==0:
    print(sub1)
    print(sub2)
    print(sub3)
    print(sub4)
    print(sub5)
    print(sub6)

mesh.paint_uniform_color([0.9, 0.1, 0.1])

mesh_t = copy.deepcopy(mesh).transform(rot1)

mesh_t2 = copy.deepcopy(mesh).transform(rot2)

mesh_t3 = copy.deepcopy(mesh).transform(rot3)
mesh_t4 = copy.deepcopy(mesh).transform(rot4)
mesh_t5 = copy.deepcopy(mesh).transform(rot5)
mesh_t6 = copy.deepcopy(mesh).transform(rot6)

#scanned tool positions 
mesh_t = mesh_t.translate(axisdiff1)
mesh_t2 = mesh_t2.translate(axisdiff2)
mesh_t3 = mesh_t3.translate(axisdiff3)
mesh_t4 = mesh_t4.translate(axisdiff4)
mesh_t5 = mesh_t5.translate(axisdiff5)
mesh_t6 = mesh_t6.translate(axisdiff6)


 



o3d.visualization.draw_geometries([mesh,mesh1,mesh2,mesh3,mesh4,mesh5,mesh6,
                                   mesh1t,mesh2t,mesh3t,mesh4t,mesh5t,mesh6t,
                                   mesh_t, mesh_t2,mesh_t3, mesh_t4,mesh_t5, mesh_t6,
                                   ])
