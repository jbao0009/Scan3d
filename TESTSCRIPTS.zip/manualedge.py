
import numpy as np
import cv2 
from PIL import Image as pil
import matplotlib.pyplot as plt
import open3d as o3d
import copy


def get_contour_areas(contours):

    all_areas= []

    for cnt in contours:
        area= cv2.contourArea(cnt)
        all_areas.append(area)

    return all_areas


dpath="/home/yimu/Downloads/plytest/Meshd.ply"
 
 
pcd_r = o3d.io.read_point_cloud(dpath)
 



pcd_r = copy.deepcopy(pcd_r).translate((0,200, 0))
 
 
#o3d.io.write_point_cloud("rotatedsurface.ply", pcd_r, write_ascii=write_text)

np_val=np.array(pcd_r.points)

npconv=[]



#print(np_val.shape)

np_val = np.delete(np_val, 2, 1)
 
 
data = pil.fromarray(np_val)
 
scale=10



x=np_val[:, 0]
y=np_val[:, 1]

img = np.zeros((580*scale,500*scale),dtype=np.uint8)

for i in range(np_val.shape[0]):
    a=round(np_val[i,0]*scale+10*scale)
    #print(a)
    b=round(np_val[i,1]*scale)
    b=np.int0(b)
    a=np.int0(a)
    img[a,b]=255
    


#blur image for canny edge detect 
blurred = cv2.GaussianBlur(img, (7, 7), 0)

blurred = cv2.GaussianBlur(blurred, (5, 5), 0)



tight = cv2.Canny(blurred, 300, 250)

conto = cv2.Canny(blurred, 300, 250)

#binary image for contours 
ret, thresh = cv2.threshold(blurred, 1, 255, cv2.THRESH_BINARY)

thresh = cv2.GaussianBlur(thresh, (5, 5), 0)

kernel = np.ones((5, 5), np.uint8)

img_dilation = cv2.dilate(thresh, kernel, iterations=20)

#cv2.imshow("dia", img_dilation)


ret, img_dilation = cv2.threshold(img_dilation, 230, 255, cv2.THRESH_BINARY)

img_dilation = cv2.GaussianBlur(img_dilation, (9, 9), 0)

cv2.imwrite("img_dilation.png", img_dilation)

contours, hierarchy = cv2.findContours(image=img_dilation, mode=cv2.RETR_TREE, method=cv2.CHAIN_APPROX_NONE)

thresh = cv2.cvtColor(thresh, cv2.COLOR_GRAY2BGR)    

#sort contours by size and get 3 largest 

sorted_contours= sorted(contours, key=cv2.contourArea, reverse= True)

sorted_contours=sorted_contours[:6]


cv2.drawContours(image=thresh, contours=sorted_contours, contourIdx=-1, color=(0, 255, 0), thickness=2, lineType=cv2.LINE_AA)

# Filename
filename = 'cadtest.png'
  
# Using cv2.imwrite() method
# Saving the image
cv2.imwrite(filename, thresh)



cv2.namedWindow('show', cv2.WINDOW_NORMAL)
cv2.namedWindow('dialte', cv2.WINDOW_NORMAL)
cv2.namedWindow('contour', cv2.WINDOW_NORMAL)
cv2.namedWindow('blurred', cv2.WINDOW_NORMAL)


wins=(48000, 24000)
thresh = cv2.resize(thresh, wins)

cv2.imshow("show", thresh)

thresh = cv2.resize(img_dilation,wins)
cv2.imshow("dialte", img_dilation)

thresh = cv2.resize(conto, wins)
thresh = cv2.resize(blurred, wins)

cv2.imshow("contour", conto)
cv2.imshow("blurred", blurred)
#cv2.imshow("contor", contours)

cv2.waitKey(0)
cv2.destroyAllWindows()